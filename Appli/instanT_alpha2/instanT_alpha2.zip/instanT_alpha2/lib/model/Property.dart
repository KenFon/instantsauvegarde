


class Property{
  String id;
  String propertyName;
  String propertyPrice;
  String propertyDesc;
  String propertyLocation;
  String image;

  Property({this.id, this.propertyName, this.propertyPrice, this.propertyDesc,this.image,this.propertyLocation});


}